// ==UserScript==
// @name         BiliBili视频速度控制
// @namespace    Ken
// @version      0.1
// @description  自定义Bilibili视频播放速度
// @author       NicerWang
// @match        https://www.bilibili.com/*
// ==/UserScript==

;(function () {
  'use strict'
  // @match        https://www.bilibili.com/video/*
  // @match        https://www.bilibili.com/bangumi/play/*
  let speeds
  let speed = 3
  let selected = false
  let isBangumi = false
  // 番剧/普通视频检测
  const getSpeeds = () => {
    document.querySelector('video').playbackRate = speed
  }

  // 分P/分集切换检测函数
  async function registerVideoChangeHandler () {
    const observer = new MutationObserver(e => {
      if (e[0].target.src) {
        getSpeeds()
        // init()
      }
    })
    observer.observe(document.querySelector('#bilibili-player video'), {
      attributes: true
    })
  }
  // 初始化
  let timer = setInterval(() => {
    getSpeeds()
    if (speeds.length != 0) {
      clearInterval(timer)
      // 默认恢复到1.0x
      speeds[0].click()
      init()
      registerVideoChangeHandler()
    }
  }, 300)

  const init = () => {

  }
})()
