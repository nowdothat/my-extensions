// ==UserScript==
// @name         settimeout
// @namespace    http://tampermonkey.net/
// @version      2024-01-07
// @description  try to take over the world!
// @author       You
// @match        https://www.ruanyifeng.com/*
// @icon         data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    // 重写 setTimeout 和 setInterval 函数
for (let i = 0; i < 1000; i++) {
  clearTimeout(i)
}
    // Your code here...
})();