// ==UserScript==
// @name         zhihu-copy
// @namespace    http://tampermonkey.net/
// @version      2024-01-11
// @description  try to take over the world!
// @author       You
// @match        https://www.zhihu.com/question/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=zhihu.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

document.addEventListener('keyup', function() {
  var selectedText = getSelectedText();
  copyAction(selectedText)
});


document.addEventListener('mouseup', function() {
  // 等待一小段时间，以确保在鼠标选中后再使用键盘继续选中时能够获取到正确的选中文本
  setTimeout(function() {
    var selectedText = getSelectedText();
    console.log('选中的文本：', selectedText);
    copyAction(selectedText)
}, 100);
});

function copyAction(text){
  navigator.clipboard.writeText(text)
  .then(function() {
      console.log('文本已成功复制到剪贴板');
  })
  .catch(function(err) {
      console.error('无法复制文本到剪贴板', err);
  });
}

function getSelectedText() {
  var selectedText = '';
  if (window.getSelection) {
      selectedText = window.getSelection().toString();
  } else if (document.selection && document.selection.type != 'Control') {
      selectedText = document.selection.createRange().text;
  }
  return selectedText;
}

})();