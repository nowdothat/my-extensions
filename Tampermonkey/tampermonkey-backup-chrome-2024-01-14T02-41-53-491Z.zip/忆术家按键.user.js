// ==UserScript==
// @name         忆术家按键
// @namespace    http://tampermonkey.net/
// @version      2024-01-10
// @description  try to take over the world!
// @author       You
// @match        https://app.memrise.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=memrise.com
// @grant        none
// ==/UserScript==
(function() {
  'use strict';



function domChecker(selector, callback) {
  const checker = setInterval(() => {
      const element = document.querySelector(selector);
      if (element) {
          callback();
          // 清除定时器
          clearInterval(checker);
          console.log('页面载入完成');
      }
  }, 300);
}


let domTarget = '.sc-beySPh'
// 监听
domChecker(domTarget, () => {
  let form = document.querySelector(domTarget);
  try {
      form.removeEventListener('keydown');
    } catch (error) {
    }
  form.addEventListener('keydown', (e) => {
      e.stopPropagation();
      if (e.key === 'Enter') {
         form.click();
      }
  }, true);
});


})();