// ==UserScript==
// @name         移除登录
// @namespace    http://tampermonkey.net/
// @version      2024-01-10
// @description  try to take over the world!
// @author       You
// @match        https://blog.csdn.net/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=csdn.net
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

let timeId
let count = 1
timeId = setInterval(() => {
  let target = document.querySelector('.passport-login-container')

  if(target) {
    target.remove()
  }
  count+= 1;
  if(count > 1000) {
    clearInterval(timeId)
  }
}, 1000);


    // Your code here...
})();